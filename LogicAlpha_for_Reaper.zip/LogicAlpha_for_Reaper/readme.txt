単なるツールに過ぎないので、改変と再配布は基本的にOK。ただし、あくまでも試作品なので、導入や使用等は自己責任でお願いいたします。

導入や使用等をされる前に、必ずバックアップを取ってください。

導入する場合は、こちらのディレクトリに入れてください。

・LogicAlpha.ReaperKeyMaps

Macintosh HD/Users/~/Library/Application Support/REAPER/KeyMaps

・LogicAlpha.ReaperMouseMaps

Macintosh HD/Users/~/Library/Application Support/REAPER/MouseMaps

そしてReaperを起動し、「アクション/アクションリストを開く/キーマップ/import shortcuts/custom actions, Import all sections/」で「LogicAlpha.ReaperKeyMaps」を開いてください。

その後、「Settings/編集動作/マウスコマンド/読込書出」より、「全項目のマウスコマンドを読み込む」で「LogicAlpha.ReaperMouseMaps」を開いて適用してください。

-----

This is just a tool, so modification and redistribution is basically OK, but it is only a prototype, so please install and use it at your own risk.

Please make sure to back up your files before installing or using.

When installing, please put the files in this directory.

LogicAlpha.ReaperKeyMaps

Macintosh HD/Users/~/Library/Application Support/REAPER/KeyMaps

LogicAlpha.ReaperMouseMaps

Macintosh HD/Users/~/Library/Application Support/REAPER/MouseMaps

Then start Reaper and open “LogicAlpha.ReaperKeyMaps” under “Actions/Open Action List/KeyMaps/import shortcuts/custom actions, Import all sections/”.

ReaperMouseMaps” in ‘Settings/Edit actions/Mouse commands/Read and write’.

-----

단순한 도구일 뿐이므로, 개편과 재배포는 기본적으로 OK입니다. 단, 어디까지나 시제품이기 때문에 도입이나 사용 등은 자기 책임으로 부탁드립니다.

도입이나 사용 등을 하시기 전에 반드시 백업을 취하십시오.

도입하는 경우는, 이쪽의 디렉토리에 넣어 주세요.

・LogicAlpha.ReaperKeyMaps

Macintosh HD/Users/~/Library/Application Support/REAPER/KeyMaps

・LogicAlpha.ReaperMouseMaps

Macintosh HD/Users/~/Library/Application Support/REAPER/MouseMaps

그리고 Reaper를 실행하고 "액션/액션 리스트 열기/키맵/import shortcuts/custom actions, Import all sections/"에서 "Logic Alpha. Reaper KeyMaps"를 열어주세요.

그 후, 「Settings/편집 동작/마우스 커맨드/읽기서출」에서, 「모든 항목의 마우스 커맨드 불러오기」로 「Logic Alpha. Reaper Mouse Maps」를 열어 적용해 주세요.

-----

©︎ 2025 Tsuikyu Music
Attribution 4.0 International CC BY 4.0 Deed
https://creativecommons.org/licenses/by/4.0/